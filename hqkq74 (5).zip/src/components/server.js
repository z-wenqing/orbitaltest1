const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const connection = mysql.createConnection({
  host: "aws.connect.psdb.cloud",
  user: "aahmmb60mpxtyfhsrb8i",
  password: "pscale_pw_PbX4vhDigA0JgAZZhHEUjglcTabBIQ13nnMvDfc1qIV",
  database: "orbital5679",
  ssl: { rejectUnauthorized: false },
  multipleStatements: true
});

connection.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL database:", err);
  } else {
    console.log("Connected to MySQL database");
  }
});

app.get("/data", (req, res) => {
  const query = "SELECT * FROM users";
  connection.query(query, (err, results) => {
    if (err) {
      console.error("Error executing query:", err);
      res.status(500).json({ error: "Internal Server Error" });
    } else {
      res.json(results);
    }
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
