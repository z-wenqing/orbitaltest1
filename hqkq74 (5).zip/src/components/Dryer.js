import logo from "./laundry-icon-1.jpg";
import { Button } from "@nextui-org/react";

export default function TaskList() {
  return (
    <>
      <table class="center">
        <thead>
          <tr>
            <th></th>
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <img src={logo} />
            </td>
            <td>
              <img src={logo} />
            </td>
            <td>
              <img src={logo} />
            </td>
            <td>
              <img src={logo} />
            </td>
          </tr>

          <tr>
            <td>Dryer 1</td>
            <td>Dryer 2</td>
            <td>Dryer 3</td>
            <td>Dryer 4</td>
          </tr>

          <tr>
            <td>
              <Button size="sm">Available</Button>
            </td>
            <td>
              <Button size="sm">Available</Button>
            </td>
            <td>
              <Button disabled size="sm">
                Unavailable
              </Button>
            </td>
            <td>
              <Button size="sm">Available</Button>
            </td>
          </tr>
        </tbody>
      </table>
    </>
  );
}
