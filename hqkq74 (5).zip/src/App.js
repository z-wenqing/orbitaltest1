import "./styles.css";
import WelcomeBanner from "./components/WelcomeBanner";
import WashingMachine from "./components/WashingMachine";
import Dryer from "./components/Dryer";

import React from "react";
import Select from "react-select";
import "bootstrap/dist/css/bootstrap.min.css";
import DatabaseReader from "./components/DatabaseReader";

const actions = [
  { label: "RVRC Block A", value: 1 },
  { label: "RVRC Block B", value: 2 },
  { label: "RVRC Block C", value: 3 }
];

/* const dropdownoptions = (value) => {
  if (value === 1) {
    return (
      <>
        <WashingMachine />
        <Dryer />
      </>
    );
  }
}; */

export default function App() {
  return (
    <>
      <DatabaseReader />
      <div className="App">
        <WelcomeBanner />
      </div>

      <div className="container">
        <div className="row">
          <div className="col-md-4"></div>
          <div className="col-md-4">
            <Select options={actions} />
          </div>
          <div className="col-md-4"></div>
        </div>
      </div>
      <WashingMachine />
      <Dryer />
    </>
  );
}
